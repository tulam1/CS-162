/****************************************************************************************
 * Program: link_list_node.cpp
 * Author: Tu Lam
 * Date: 05/28/2019
 * Description: The implementation file that contain the function to use for the program.
 * Input: None.
 * Output: None.
 ***************************************************************************************/

#include <iostream>
#include <string>
#include <cstdlib>
#include "link_list_node.h"

using namespace std;
